# 낱다이 자동계산기 — Android ML Kit 무료 버전

이 프로젝트는 기존 PWA/Tesseract 대신 Google ML Kit 한국어 Text Recognition을
안드로이드 앱 안에서 직접 사용합니다.

## 핵심
- OpenAI API 키 필요 없음
- 사용량 과금 없음
- 출고장 사진을 외부 AI 서버로 보내지 않음
- 한국어 OCR 모델을 앱에 포함
- 사진 촬영 / 갤러리 선택
- 표 헤더 위치를 읽어 품명 / 상품코드 / BOX / PLT 열을 분리
- 1.04, 1.58, 2.18 같은 혼합 PLT만 결과에 표시
- 센터명은 결과에서 제외
- 수동 계산은 총 BOX + PLT만 입력

## 기준 계산
- 50 BOX / 1.04 PLT → 48 BOX 완파레트 + 2 BOX 낱다이
- 189 BOX / 1.58 PLT → 120 BOX 완파레트 + 69 BOX 낱다이
- 33.00, 6.00, 2.00 같은 정수 PLT → 제외
- 0.17, 0.21 같은 1 미만 PLT → 제외

## 휴대폰만 있을 때 APK 만들기
이 프로젝트에는 `.github/workflows/build-apk.yml`이 들어 있습니다.

GitHub 저장소에 프로젝트 파일 전체를 올리면 GitHub Actions가 자동으로 APK를 빌드합니다.

1. GitHub에서 새 저장소 생성
2. 이 ZIP을 압축 해제한 뒤 프로젝트 파일 전체를 저장소 루트에 업로드
3. `Actions` 탭 → `Build Android APK`
4. 빌드가 끝나면 실행 결과의 `Artifacts`에서 `loosebox-calculator-apk` 다운로드
5. 압축을 풀어 `app-debug.apk`를 갤럭시에 설치

`main` 브랜치에 올리면 자동 빌드되며, Actions의 `Run workflow`로 수동 빌드도 가능합니다.

## 빌드 환경
- Android Gradle Plugin 9.2.0
- Gradle 9.4.1
- compileSdk 36
- minSdk 29
- Java 17
- ML Kit Korean Text Recognition 16.0.1

## 실제 테스트 때
앱에서 사진 분석 후 잘못 인식되면 `인식 원문 보기`를 눌러
OCR이 읽은 값과 열 분석 값을 확인할 수 있습니다.
그 화면 캡처를 기준으로 파싱 규칙을 추가 조정할 수 있습니다.
