package com.safeasy.loosebox;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.ImageDecoder;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;

import com.google.mlkit.vision.documentscanner.GmsDocumentScanner;
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends ComponentActivity {

    private static final int REQ_GALLERY = 1002;

    private final int BG = Color.rgb(11, 13, 16);
    private final int PANEL = Color.rgb(21, 25, 34);
    private final int TEXT = Color.rgb(245, 247, 251);
    private final int MUTED = Color.rgb(174, 182, 197);
    private final int ACCENT = Color.rgb(110, 168, 255);
    private final int GOOD = Color.rgb(61, 220, 151);
    private final int DANGER = Color.rgb(255, 107, 107);

    private ImageView preview;
    private TextView status;
    private LinearLayout resultsContainer;
    private LinearLayout pageSelector;
    private ProgressBar progress;
    private Button analyzeButton;
    private Button rawButton;
    private TextView rawText;
    private EditText manualBoxes;
    private EditText manualPlt;

    private Uri imageUri;
    private final List<Uri> imageUris = new ArrayList<>();
    private String lastRawText = "";
    private final List<PageResult> currentPageResults = new ArrayList<>();
    private int selectedPageIndex = 0;

    private TextRecognizer recognizer;
    private ActivityResultLauncher<IntentSenderRequest> scannerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        scannerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartIntentSenderForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        GmsDocumentScanningResult scanResult =
                                GmsDocumentScanningResult.fromActivityResultIntent(
                                        result.getData()
                                );

                        if (scanResult != null
                                && scanResult.getPages() != null
                                && !scanResult.getPages().isEmpty()) {

                            List<Uri> scannedUris = new ArrayList<>();
                            for (GmsDocumentScanningResult.Page page : scanResult.getPages()) {
                                scannedUris.add(page.getImageUri());
                            }

                            setImages(scannedUris);
                            status.setTextColor(GOOD);
                            status.setText(
                                    "출고장 " + scannedUris.size()
                                            + "장 보정 완료. 장별로 자동 분석합니다."
                            );

                            preview.postDelayed(this::analyzeImage, 180);
                        } else {
                            status.setTextColor(DANGER);
                            status.setText("스캔된 출고장 이미지를 가져오지 못했습니다.");
                        }
                    } else {
                        status.setTextColor(MUTED);
                        status.setText("문서 스캔이 취소되었습니다.");
                    }
                }
        );

        recognizer = TextRecognition.getClient(
                new KoreanTextRecognizerOptions.Builder().build()
        );

        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);

        LinearLayout root = column();
        root.setPadding(dp(16), dp(18), dp(16), dp(40));
        scroll.addView(root);

        TextView title = text("낱다이 자동계산기", 26, TEXT, true);
        root.addView(title);

        TextView version = text("ML Kit v15 · 결과 간소화", 13, GOOD, true);
        root.addView(version, lpMatchWrap(0, dp(4)));

        TextView subtitle = text(
                "출고장을 문서처럼 자동 보정해 읽고, 완파레트+낱다이가 섞인 항목만 찾아 낱다이 BOX를 계산합니다.",
                14, MUTED, false
        );
        root.addView(subtitle, lpMatchWrap(0, dp(14)));

        // Photo card
        LinearLayout photoCard = card();
        root.addView(photoCard, lpMatchWrap(0, dp(12)));

        LinearLayout photoButtons = new LinearLayout(this);
        photoButtons.setOrientation(LinearLayout.HORIZONTAL);
        photoButtons.setGravity(Gravity.CENTER);
        photoButtons.setWeightSum(2f);

        Button camera = button("📄 출고장 스캔", ACCENT, Color.rgb(7,17,31));
        Button gallery = button("🖼️ 사진 선택", Color.rgb(32,38,52), TEXT);
        photoButtons.addView(camera, new LinearLayout.LayoutParams(0, dp(54), 1f));
        LinearLayout.LayoutParams galleryLp = new LinearLayout.LayoutParams(0, dp(54), 1f);
        galleryLp.setMargins(dp(8),0,0,0);
        photoButtons.addView(gallery, galleryLp);
        photoCard.addView(photoButtons);

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackgroundColor(Color.rgb(9,11,15));
        preview.setVisibility(View.GONE);
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        previewLp.setMargins(0, dp(10), 0, 0);
        photoCard.addView(preview, previewLp);

        analyzeButton = button("🔎 사진 분석하기", ACCENT, Color.rgb(7,17,31));
        analyzeButton.setEnabled(false);
        photoCard.addView(analyzeButton, lpMatch(dp(54), dp(10)));

        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        photoCard.addView(progress, lpMatchWrap(0, dp(8)));

        status = text("사진을 먼저 촬영하거나 선택하세요.", 14, MUTED, false);
        photoCard.addView(status, lpMatchWrap(0, dp(8)));

        rawButton = button("사진 초기화", Color.rgb(32,38,52), TEXT);
        rawButton.setVisibility(View.GONE);
        photoCard.addView(rawButton, lpMatch(dp(46), dp(8)));

        rawText = text("", 12, MUTED, false);
        rawText.setVisibility(View.GONE);
        rawText.setTextIsSelectable(true);
        photoCard.addView(rawText, lpMatchWrap(0, dp(8)));

        camera.setOnClickListener(v -> { resetForNewWork(); openCamera(); });
        gallery.setOnClickListener(v -> { resetForNewWork(); openGallery(); });
        analyzeButton.setOnClickListener(v -> analyzeImage());
        rawButton.setOnClickListener(v -> resetForNewWork());

        // Results card
        LinearLayout resultCard = card();
        root.addView(resultCard, lpMatchWrap(0, dp(12)));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout headerText = column();
        headerText.addView(text("계산 결과", 22, TEXT, true));
        headerText.addView(text("장 번호를 눌러 품명과 챙길 낱다이만 확인합니다.", 13, MUTED, false));
        header.addView(headerText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button clear = button("새 작업", Color.rgb(63,26,26), Color.rgb(255,214,214));
        header.addView(clear, new LinearLayout.LayoutParams(dp(108), dp(44)));
        resultCard.addView(header);

        HorizontalScrollView pageScroll = new HorizontalScrollView(this);
        pageScroll.setHorizontalScrollBarEnabled(false);
        pageScroll.setFillViewport(false);

        pageSelector = new LinearLayout(this);
        pageSelector.setOrientation(LinearLayout.HORIZONTAL);
        pageSelector.setGravity(Gravity.CENTER_VERTICAL);
        pageScroll.addView(
                pageSelector,
                new HorizontalScrollView.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );
        pageScroll.setVisibility(View.GONE);
        resultCard.addView(pageScroll, lpMatch(dp(52), dp(10)));
        pageSelector.setTag(pageScroll);

        resultsContainer = column();
        resultCard.addView(resultsContainer, lpMatchWrap(0, dp(10)));
        showEmpty();

        clear.setOnClickListener(v -> resetForNewWork());

        // Manual card
        LinearLayout manualCard = card();
        root.addView(manualCard, lpMatchWrap(0, dp(12)));
        manualCard.addView(text("수동 계산", 20, TEXT, true));
        manualCard.addView(text("사진 인식이 놓친 경우 총 BOX와 PLT만 입력하세요.", 13, MUTED, false));

        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.HORIZONTAL);
        fields.setWeightSum(2f);

        manualBoxes = numberInput("총 BOX 예: 50");
        manualPlt = decimalInput("PLT 예: 1.04");
        fields.addView(manualBoxes, new LinearLayout.LayoutParams(0, dp(52), 1f));
        LinearLayout.LayoutParams pltLp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        pltLp.setMargins(dp(8),0,0,0);
        fields.addView(manualPlt, pltLp);

        manualCard.addView(fields, lpMatchWrap(0, dp(10)));

        Button manualAdd = button("직접 계산해서 추가", Color.rgb(32,38,52), TEXT);
        manualCard.addView(manualAdd, lpMatch(dp(50), dp(8)));
        manualAdd.setOnClickListener(v -> manualCalculate());

        // Privacy card
        LinearLayout privacy = card();
        root.addView(privacy, lpMatchWrap(0, dp(12)));
        TextView privacyText = text(
                "🔒 OpenAI API나 사용료는 없습니다. 문서 스캔 UI는 Google Play 서비스가 제공하고, 문자 인식과 낱다이 계산은 기기에서 처리합니다.",
                13, MUTED, false
        );
        privacy.addView(privacyText);

        return scroll;
    }

    private void openCamera() {
        status.setTextColor(MUTED);
        status.setText("문서 스캐너를 준비하는 중… 첫 실행은 잠시 걸릴 수 있습니다.");

        GmsDocumentScannerOptions options =
                new GmsDocumentScannerOptions.Builder()
                        .setGalleryImportAllowed(false)
                        .setPageLimit(10)
                        .setResultFormats(
                                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG
                        )
                        .setScannerMode(
                                GmsDocumentScannerOptions.SCANNER_MODE_FULL
                        )
                        .build();

        GmsDocumentScanner scanner =
                GmsDocumentScanning.getClient(options);

        scanner.getStartScanIntent(this)
                .addOnSuccessListener(intentSender ->
                        scannerLauncher.launch(
                                new IntentSenderRequest.Builder(intentSender)
                                        .build()
                        )
                )
                .addOnFailureListener(e -> {
                    status.setTextColor(DANGER);
                    status.setText(
                            "문서 스캐너를 열지 못했습니다. "
                                    + "첫 실행이면 잠시 후 다시 시도하거나 사진 선택을 이용해주세요.\n"
                                    + (e.getMessage() == null ? "" : e.getMessage())
                    );
                });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, REQ_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_GALLERY && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(
                            uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );
                } catch (Exception ignored) {}

                setImage(uri);
                status.setTextColor(MUTED);
                status.setText("사진이 준비되었습니다. “사진 분석하기”를 누르세요.");
            }
        }
    }




    private void resetForNewWork() {
        imageUri = null;
        imageUris.clear();
        lastRawText = "";
        currentPageResults.clear();
        selectedPageIndex = 0;
        if (pageSelector != null) {
            pageSelector.removeAllViews();
            View parentScroll = (View) pageSelector.getTag();
            if (parentScroll != null) parentScroll.setVisibility(View.GONE);
        }

        preview.setImageDrawable(null);
        preview.setVisibility(View.GONE);

        analyzeButton.setEnabled(false);

        rawButton.setVisibility(View.GONE);
        rawText.setText("");
        rawText.setVisibility(View.GONE);

        progress.setVisibility(View.GONE);

        showEmpty();

        status.setTextColor(MUTED);
        status.setText("새 작업 준비 완료. 출고장을 스캔하거나 사진을 선택하세요.");
    }

    private void setImage(Uri uri) {
        List<Uri> one = new ArrayList<>();
        one.add(uri);
        setImages(one);
    }

    private void setImages(List<Uri> uris) {
        imageUris.clear();
        imageUris.addAll(uris);

        imageUri = imageUris.isEmpty() ? null : imageUris.get(0);

        if (imageUri != null) {
            preview.setImageURI(imageUri);
            preview.setVisibility(View.VISIBLE);
            analyzeButton.setEnabled(true);
            rawButton.setVisibility(View.VISIBLE);
        } else {
            preview.setImageDrawable(null);
            preview.setVisibility(View.GONE);
            analyzeButton.setEnabled(false);
            rawButton.setVisibility(View.GONE);
        }

        rawText.setVisibility(View.GONE);
        lastRawText = "";

        status.setTextColor(MUTED);
        if (imageUris.size() > 1) {
            status.setText(
                    "출고장 " + imageUris.size()
                            + "장이 준비되었습니다. 장별로 분석합니다."
            );
        } else {
            status.setText("사진이 준비되었습니다. “사진 분석하기”를 누르세요.");
        }

        showEmpty();
    }

    private void analyzeImage() {
        if (imageUris.isEmpty()) {
            if (imageUri == null) return;
            imageUris.add(imageUri);
        }

        progress.setVisibility(View.VISIBLE);
        analyzeButton.setEnabled(false);
        rawButton.setVisibility(View.VISIBLE);
        status.setTextColor(MUTED);

        List<PageResult> pageResults = new ArrayList<>();
        analyzePageSequentially(0, pageResults);
    }

    private void analyzePageSequentially(int index, List<PageResult> pageResults) {
        if (index >= imageUris.size()) {
            finishAllPages(pageResults);
            return;
        }

        Uri uri = imageUris.get(index);
        int pageNumber = index + 1;

        status.setText(
                "출고장 " + pageNumber + "/" + imageUris.size()
                        + "장 1차 인식 중…"
        );

        try {
            InputImage image = InputImage.fromFilePath(this, uri);

            recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        ParseOutput first = parseRecognizedText(
                                result,
                                image.getWidth(),
                                image.getHeight()
                        );

                        if (first.items.isEmpty()) {
                            status.setText(
                                    "출고장 " + pageNumber + "/"
                                            + imageUris.size()
                                            + "장 정밀 인식 중…"
                            );

                            runEnhancedOcrForPage(
                                    uri,
                                    first,
                                    parsed -> {
                                        pageResults.add(
                                                new PageResult(pageNumber, parsed.items, parsed.raw)
                                        );
                                        analyzePageSequentially(index + 1, pageResults);
                                    }
                            );
                        } else {
                            pageResults.add(
                                    new PageResult(pageNumber, first.items, first.raw)
                            );
                            analyzePageSequentially(index + 1, pageResults);
                        }
                    })
                    .addOnFailureListener(e -> {
                        pageResults.add(
                                new PageResult(
                                        pageNumber,
                                        new ArrayList<>(),
                                        "인식 실패: " + e.getMessage()
                                )
                        );
                        analyzePageSequentially(index + 1, pageResults);
                    });

        } catch (IOException e) {
            pageResults.add(
                    new PageResult(
                            pageNumber,
                            new ArrayList<>(),
                            "사진 열기 실패: " + e.getMessage()
                    )
            );
            analyzePageSequentially(index + 1, pageResults);
        }
    }

    private void runEnhancedOcrForPage(
            Uri uri,
            ParseOutput first,
            java.util.function.Consumer<ParseOutput> callback
    ) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(
                    getContentResolver(),
                    uri
            );

            Bitmap original = ImageDecoder.decodeBitmap(
                    source,
                    (decoder, info, src) ->
                            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
            );

            Bitmap enhanced = enhanceForText(original);
            InputImage secondImage = InputImage.fromBitmap(enhanced, 0);

            recognizer.process(secondImage)
                    .addOnSuccessListener(result -> {
                        ParseOutput second = parseRecognizedText(
                                result,
                                enhanced.getWidth(),
                                enhanced.getHeight()
                        );

                        ParseOutput chosen =
                                second.items.size() > first.items.size()
                                        ? second
                                        : first;

                        chosen.raw =
                                first.raw
                                        + "\n\n===== 정밀 인식 재시도 =====\n"
                                        + second.raw;

                        callback.accept(chosen);

                        if (!original.isRecycled()) original.recycle();
                        if (!enhanced.isRecycled()) enhanced.recycle();
                    })
                    .addOnFailureListener(e -> {
                        callback.accept(first);
                        if (!original.isRecycled()) original.recycle();
                        if (!enhanced.isRecycled()) enhanced.recycle();
                    });

        } catch (Exception e) {
            callback.accept(first);
        }
    }

    private Bitmap enhanceForText(Bitmap src) {
        Bitmap out = Bitmap.createBitmap(
                src.getWidth(),
                src.getHeight(),
                Bitmap.Config.ARGB_8888
        );

        Canvas canvas = new Canvas(out);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        ColorMatrix gray = new ColorMatrix();
        gray.setSaturation(0f);

        float contrast = 1.35f;
        float translate = (-0.5f * contrast + 0.5f) * 255f;

        ColorMatrix contrastMatrix = new ColorMatrix(new float[]{
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });

        gray.postConcat(contrastMatrix);
        paint.setColorFilter(new ColorMatrixColorFilter(gray));

        canvas.drawBitmap(src, 0, 0, paint);
        return out;
    }

    private void finishAllPages(List<PageResult> pageResults) {
        progress.setVisibility(View.GONE);
        analyzeButton.setEnabled(true);
        rawButton.setVisibility(View.VISIBLE);

        StringBuilder raw = new StringBuilder();
        int totalItems = 0;

        for (PageResult page : pageResults) {
            raw.append("===== ")
                    .append(page.pageNumber)
                    .append("장 =====\n")
                    .append(page.raw)
                    .append("\n\n");

            totalItems += page.items.size();
        }

        lastRawText = raw.toString();
        rawText.setText(lastRawText);
        rawText.setVisibility(View.GONE);

        renderPageResults(pageResults);

        if (totalItems == 0) {
            status.setTextColor(Color.rgb(255,189,102));
            status.setText(
                    "전체 " + pageResults.size()
                            + "장을 확인했지만 혼합 PLT를 찾지 못했습니다."
            );
        } else {
            status.setTextColor(GOOD);
            status.setText(
                    "출고장 " + pageResults.size()
                            + "장 분석 완료 · 혼합 PLT 총 "
                            + totalItems + "건"
            );
        }
    }

    private ParseOutput parseRecognizedText(Text result, int imageWidth, int imageHeight) {
        List<Word> words = new ArrayList<>();
        StringBuilder allText = new StringBuilder();

        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                allText.append(line.getText()).append('\n');
                for (Text.Element element : line.getElements()) {
                    Rect r = element.getBoundingBox();
                    if (r != null && !element.getText().trim().isEmpty()) {
                        words.add(new Word(element.getText(), r));
                    }
                }
            }
        }

        Word centerHeader = findHeader(words, "센터명");
        Word nameHeader = findHeader(words, "품명");
        Word codeHeader = findHeader(words, "상품코드");
        Word boxHeader = findHeader(words, "박스");
        Word pltHeader = findHeader(words, "PLT");
        Word checkHeader = findHeader(words, "체크");

        float nameMin, nameMax, codeMin, codeMax, boxMin, boxMax, pltMin, pltMax;
        float headerY;

        if (nameHeader != null && codeHeader != null && boxHeader != null && pltHeader != null) {
            float centerX = centerHeader != null ? centerHeader.cx : imageWidth * 0.15f;
            nameMin = mid(centerX, nameHeader.cx);
            nameMax = mid(nameHeader.cx, codeHeader.cx);
            codeMin = nameMax;
            codeMax = mid(codeHeader.cx, boxHeader.cx);
            boxMin = codeMax;
            boxMax = mid(boxHeader.cx, pltHeader.cx);
            pltMin = boxMax;
            pltMax = checkHeader != null ? mid(pltHeader.cx, checkHeader.cx) : pltHeader.cx + imageWidth * 0.07f;
            headerY = Math.max(Math.max(nameHeader.cy, codeHeader.cy), Math.max(boxHeader.cy, pltHeader.cy));
        } else {
            // 이 회사 출고장 양식의 상대 위치 fallback
            nameMin = imageWidth * 0.18f;
            nameMax = imageWidth * 0.50f;
            codeMin = imageWidth * 0.50f;
            codeMax = imageWidth * 0.59f;
            boxMin = imageWidth * 0.59f;
            boxMax = imageWidth * 0.66f;
            pltMin = imageWidth * 0.66f;
            pltMax = imageWidth * 0.74f;
            headerY = imageHeight * 0.07f;
        }

        List<Row> rows = groupRows(words, headerY + 4, imageHeight * 0.86f);
        List<Item> items = new ArrayList<>();
        StringBuilder debug = new StringBuilder();

        for (Row row : rows) {
            String name = joinInRange(row.words, nameMin, nameMax);
            String codeText = joinInRange(row.words, codeMin, codeMax);
            String boxText = joinInRange(row.words, boxMin, boxMax);
            String pltText = joinInRange(row.words, pltMin, pltMax);

            String code = digits(codeText);
            Integer boxes = parseBox(boxText);

            debug.append(String.format(
                    Locale.US,
                    "품명=[%s] 코드=[%s] BOX=[%s] PLT=[%s]\n",
                    name, codeText, boxText, pltText
            ));

            if (boxes == null) continue;

            List<Double> candidates = pltCandidates(pltText, boxes);
            Calculation chosen = null;
            double chosenPlt = 0;

            for (double plt : candidates) {
                if (plt <= 1 || Math.abs(plt - Math.rint(plt)) < 0.0001) continue;
                Calculation c = calculateLoose(boxes, plt);
                if (c != null) {
                    chosen = c;
                    chosenPlt = plt;
                    break;
                }
            }

            if (chosen == null) continue;

            name = cleanName(name);
            if (name.isEmpty()) name = "품명 확인";

            items.add(new Item(
                    name,
                    code,
                    boxes,
                    chosenPlt,
                    chosen.pack,
                    chosen.loose
            ));
        }

        // 동일 코드/BOX/PLT 중복 제거
        Map<String, Item> unique = new LinkedHashMap<>();
        for (Item i : items) {
            String key = i.code + "|" + i.boxes + "|" + String.format(Locale.US, "%.2f", i.plt);
            unique.put(key, i);
        }

        return new ParseOutput(new ArrayList<>(unique.values()), allText + "\n--- 열 분석 ---\n" + debug);
    }

    private Word findHeader(List<Word> words, String target) {
        String normalizedTarget = normalize(target);
        Word best = null;
        for (Word w : words) {
            String n = normalize(w.text);
            if (n.equals(normalizedTarget) || n.contains(normalizedTarget)) {
                if (best == null || w.cy < best.cy) best = w;
            }
        }
        return best;
    }

    private List<Row> groupRows(List<Word> words, float minY, float maxY) {
        List<Word> filtered = new ArrayList<>();
        for (Word w : words) {
            if (w.cy >= minY && w.cy <= maxY) filtered.add(w);
        }
        Collections.sort(filtered, Comparator.comparingDouble(a -> a.cy));

        List<Row> rows = new ArrayList<>();

        for (Word w : filtered) {
            Row best = null;
            float bestDist = Float.MAX_VALUE;

            for (Row row : rows) {
                float tol = Math.max(10f, Math.min(28f, (row.avgHeight + w.rect.height()) * 0.75f));
                float d = Math.abs(row.cy - w.cy);
                if (d <= tol && d < bestDist) {
                    best = row;
                    bestDist = d;
                }
            }

            if (best == null) {
                Row row = new Row();
                row.words.add(w);
                row.recalculate();
                rows.add(row);
            } else {
                best.words.add(w);
                best.recalculate();
            }
        }

        for (Row row : rows) {
            Collections.sort(row.words, Comparator.comparingInt(a -> a.rect.left));
        }
        Collections.sort(rows, Comparator.comparingDouble(r -> r.cy));
        return rows;
    }

    private String joinInRange(List<Word> words, float minX, float maxX) {
        StringBuilder sb = new StringBuilder();
        for (Word w : words) {
            if (w.cx >= minX && w.cx < maxX) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(w.text);
            }
        }
        return sb.toString().trim();
    }

    private Integer parseBox(String raw) {
        String d = digits(raw);
        if (d.length() < 1 || d.length() > 5) return null;
        try {
            int v = Integer.parseInt(d);
            return v > 0 ? v : null;
        } catch (Exception e) {
            return null;
        }
    }

    private List<Double> pltCandidates(String raw, int boxes) {
        List<Double> out = new ArrayList<>();
        String n = normalize(raw).replace('O','0').replace('o','0').replace(',', '.');

        Matcher m = Pattern.compile("(\\d{1,2})\\.(\\d{1,2})").matcher(n);
        if (m.find()) {
            try {
                double v = Double.parseDouble(m.group(1) + "." + m.group(2));
                out.add(v);

                // 1.04가 4.04 / 7.04로 읽힌 경우의 제한적 보정
                int whole = (int)Math.floor(v);
                double frac = v - whole;
                if ((whole == 4 || whole == 7) && frac > 0) {
                    double corrected = Math.round((1.0 + frac) * 100.0) / 100.0;
                    if (calculateLoose(boxes, v) == null && calculateLoose(boxes, corrected) != null) {
                        out.add(0, corrected);
                    }
                }
            } catch (Exception ignored) {}
        }

        String d = digits(n);
        if (d.length() == 3 && d.charAt(0) == '1') {
            try {
                double v = Double.parseDouble(d.substring(0,1) + "." + d.substring(1));
                if (!out.contains(v)) out.add(v);
            } catch (Exception ignored) {}
        }

        return out;
    }

    private Calculation calculateLoose(int boxes, double plt) {
        int full = (int)Math.floor(plt + 1e-9);
        double frac = plt - full;
        if (boxes <= 0 || plt <= 1 || full < 1 || frac <= 0.0001) return null;

        Calculation best = null;
        double bestErr = Double.MAX_VALUE;

        for (int pack = 2; pack <= 500; pack++) {
            int loose = boxes - full * pack;
            if (loose <= 0 || loose >= pack) continue;

            double real = full + (double)loose / (double)pack;
            double rounded = Math.round(real * 100.0) / 100.0;
            double err = Math.abs(real - plt);

            if (Math.abs(rounded - plt) < 0.0001) {
                if (err < bestErr) {
                    bestErr = err;
                    best = new Calculation(pack, loose);
                }
            }
        }
        return best;
    }

    private void renderPageResults(List<PageResult> pages) {
        currentPageResults.clear();
        currentPageResults.addAll(pages);
        selectedPageIndex = 0;

        if (currentPageResults.isEmpty()) {
            if (pageSelector != null) {
                pageSelector.removeAllViews();
                View parentScroll = (View) pageSelector.getTag();
                if (parentScroll != null) parentScroll.setVisibility(View.GONE);
            }
            showEmpty();
            return;
        }

        renderPageSelector();
        renderSelectedPage();
    }

    private void renderPageSelector() {
        if (pageSelector == null) return;

        pageSelector.removeAllViews();
        View parentScroll = (View) pageSelector.getTag();

        if (currentPageResults.size() <= 1) {
            if (parentScroll != null) parentScroll.setVisibility(View.GONE);
            return;
        }

        if (parentScroll != null) parentScroll.setVisibility(View.VISIBLE);

        for (int i = 0; i < currentPageResults.size(); i++) {
            final int index = i;
            PageResult page = currentPageResults.get(i);

            String badge = circledNumber(page.pageNumber);
            String label = badge + "  " + page.pageNumber + "장";

            int bg = i == selectedPageIndex ? ACCENT : Color.rgb(32,38,52);
            int fg = i == selectedPageIndex ? Color.rgb(7,17,31) : TEXT;

            Button pageButton = button(label, bg, fg);
            pageButton.setTextSize(17);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    dp(96),
                    dp(48)
            );
            if (i > 0) lp.setMargins(dp(8), 0, 0, 0);

            pageSelector.addView(pageButton, lp);
            pageButton.setOnClickListener(v -> selectPage(index));
        }
    }

    private void selectPage(int index) {
        if (index < 0 || index >= currentPageResults.size()) return;
        selectedPageIndex = index;
        renderPageSelector();
        renderSelectedPage();
    }

    private void renderSelectedPage() {
        resultsContainer.removeAllViews();

        if (currentPageResults.isEmpty()) {
            showEmpty();
            return;
        }

        PageResult page = currentPageResults.get(selectedPageIndex);

        LinearLayout pageHeader = new LinearLayout(this);
        pageHeader.setOrientation(LinearLayout.HORIZONTAL);
        pageHeader.setGravity(Gravity.CENTER_VERTICAL);
        pageHeader.setPadding(dp(10), dp(10), dp(10), dp(8));

        TextView pageTitle = text(
                circledNumber(page.pageNumber) + "  " + page.pageNumber + "장 결과",
                21,
                ACCENT,
                true
        );
        pageHeader.addView(
                pageTitle,
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1f
                )
        );

        TextView pageCount = text(
                page.items.isEmpty()
                        ? "혼합 PLT 없음"
                        : page.items.size() + "건",
                13,
                page.items.isEmpty() ? MUTED : GOOD,
                true
        );
        pageCount.setGravity(Gravity.END);
        pageHeader.addView(
                pageCount,
                new LinearLayout.LayoutParams(
                        dp(120),
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        resultsContainer.addView(pageHeader);

        if (page.items.isEmpty()) {
            TextView none = text(
                    "이 장에서는 챙길 낱다이가 없습니다.",
                    15,
                    MUTED,
                    false
            );
            none.setPadding(dp(10), dp(12), dp(10), dp(18));
            resultsContainer.addView(none);
        } else {
            for (Item item : page.items) {
                addResultRow(item);
            }
        }
    }

    private String circledNumber(int number) {
        switch (number) {
            case 1: return "①";
            case 2: return "②";
            case 3: return "③";
            case 4: return "④";
            case 5: return "⑤";
            case 6: return "⑥";
            case 7: return "⑦";
            case 8: return "⑧";
            case 9: return "⑨";
            case 10: return "⑩";
            default: return "●";
        }
    }

    private void addResultRow(Item item) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(10), dp(14), dp(10), dp(14));
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = text(item.name, 18, TEXT, true);
        row.addView(
                name,
                new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1f
                )
        );

        TextView loose = text(
                "챙길 낱다이\n" + item.loose + " BOX",
                18,
                GOOD,
                true
        );
        loose.setGravity(Gravity.END);
        row.addView(
                loose,
                new LinearLayout.LayoutParams(
                        dp(135),
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        resultsContainer.addView(row);

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(42,49,64));
        resultsContainer.addView(
                divider,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(1)
                )
        );
    }

    private void renderResults(List<Item> items) {
        currentPageResults.clear();
        selectedPageIndex = 0;
        if (pageSelector != null) {
            pageSelector.removeAllViews();
            View parentScroll = (View) pageSelector.getTag();
            if (parentScroll != null) parentScroll.setVisibility(View.GONE);
        }

        resultsContainer.removeAllViews();

        if (items.isEmpty()) {
            showEmpty();
            return;
        }

        for (Item item : items) {
            addResultRow(item);
        }
    }

    private void manualCalculate() {
        try {
            int boxes = Integer.parseInt(manualBoxes.getText().toString().trim());
            double plt = Double.parseDouble(manualPlt.getText().toString().trim());
            Calculation c = calculateLoose(boxes, plt);
            if (c == null) {
                toast("예: 50 BOX / 1.04 PLT처럼 입력하세요.");
                return;
            }
            List<Item> one = new ArrayList<>();
            one.add(new Item("수동 계산", "", boxes, plt, c.pack, c.loose));
            renderResults(one);
            manualBoxes.setText("");
            manualPlt.setText("");
        } catch (Exception e) {
            toast("총 BOX와 PLT를 입력하세요.");
        }
    }

    private void showEmpty() {
        if (currentPageResults.isEmpty() && pageSelector != null) {
            View parentScroll = (View) pageSelector.getTag();
            if (parentScroll != null) parentScroll.setVisibility(View.GONE);
        }
        resultsContainer.removeAllViews();
        TextView empty = text("아직 결과가 없습니다.", 16, MUTED, false);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(0, dp(24), 0, dp(24));
        resultsContainer.addView(empty);
    }

    private String cleanName(String s) {
        return s == null ? "" : s
                .replaceAll("^\\[[^\\]]+\\]\\s*", "")
                .replaceAll("^[_\\-:|\\s]+", "")
                .trim();
    }

    private String normalize(String s) {
        if (s == null) return "";
        return s.replaceAll("\\s+", "")
                .replace("，", ".")
                .replace(",", ".")
                .trim();
    }

    private String digits(String s) {
        return s == null ? "" : s.replaceAll("[^0-9]", "");
    }

    private float mid(float a, float b) {
        return (a + b) / 2f;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ---------- UI helpers ----------

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout card() {
        LinearLayout l = column();
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(PANEL);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.rgb(42,49,64));
        l.setBackground(bg);
        return l;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setLineSpacing(0, 1.12f);
        return t;
    }

    private Button button(String s, int bgColor, int fgColor) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(16);
        b.setTextColor(fgColor);
        b.setAllCaps(false);
        b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);

        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        return b;
    }

    private EditText numberInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(16);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setPadding(dp(12),0,dp(12),0);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Color.rgb(15,19,26));
        bg.setCornerRadius(dp(11));
        bg.setStroke(dp(1), Color.rgb(42,49,64));
        e.setBackground(bg);
        return e;
    }

    private EditText decimalInput(String hint) {
        EditText e = numberInput(hint);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private LinearLayout.LayoutParams lpMatchWrap(int leftTop, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(leftTop, top, 0, 0);
        return lp;
    }

    private LinearLayout.LayoutParams lpMatch(int height, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                height
        );
        lp.setMargins(0, top, 0, 0);
        return lp;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------- Data classes ----------

    private static class Word {
        final String text;
        final Rect rect;
        final float cx;
        final float cy;

        Word(String text, Rect rect) {
            this.text = text;
            this.rect = rect;
            this.cx = rect.exactCenterX();
            this.cy = rect.exactCenterY();
        }
    }

    private static class Row {
        final List<Word> words = new ArrayList<>();
        float cy;
        float avgHeight;

        void recalculate() {
            float sy = 0;
            float sh = 0;
            for (Word w : words) {
                sy += w.cy;
                sh += w.rect.height();
            }
            cy = sy / words.size();
            avgHeight = sh / words.size();
        }
    }

    private static class Calculation {
        final int pack;
        final int loose;
        Calculation(int pack, int loose) {
            this.pack = pack;
            this.loose = loose;
        }
    }

    private static class Item {
        final String name;
        final String code;
        final int boxes;
        final double plt;
        final int pack;
        final int loose;

        Item(String name, String code, int boxes, double plt, int pack, int loose) {
            this.name = name;
            this.code = code;
            this.boxes = boxes;
            this.plt = plt;
            this.pack = pack;
            this.loose = loose;
        }
    }

    private static class PageResult {
        final int pageNumber;
        final List<Item> items;
        final String raw;

        PageResult(int pageNumber, List<Item> items, String raw) {
            this.pageNumber = pageNumber;
            this.items = items;
            this.raw = raw;
        }
    }

    private static class ParseOutput {
        final List<Item> items;
        String raw;
        ParseOutput(List<Item> items, String raw) {
            this.items = items;
            this.raw = raw;
        }
    }
}
