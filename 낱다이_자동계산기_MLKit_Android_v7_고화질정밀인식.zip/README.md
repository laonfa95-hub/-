# 낱다이 자동계산기 — Android ML Kit 무료 버전 v7

이 프로젝트는 기존 PWA/Tesseract 대신 Google ML Kit 한국어 Text Recognition을
안드로이드 앱 안에서 직접 사용합니다.

## 핵심
- OpenAI API 키 필요 없음
- 사용량 과금 없음
- 출고장 사진을 외부 AI 서버로 보내지 않음
- 한국어 OCR 모델을 앱에 포함
- 사진 촬영 / 갤러리 선택
- 표 헤더 위치를 읽어 품명 / 상품코드 / BOX / PLT 열을 분리
- 1.04, 1.58, 2.18 같은 혼합 PLT만 결과에 표시
- 센터명은 결과에서 제외
- 수동 계산은 총 BOX + PLT만 입력

## 기준 계산
- 50 BOX / 1.04 PLT → 48 BOX 완파레트 + 2 BOX 낱다이
- 189 BOX / 1.58 PLT → 120 BOX 완파레트 + 69 BOX 낱다이
- 33.00, 6.00, 2.00 같은 정수 PLT → 제외
- 0.17, 0.21 같은 1 미만 PLT → 제외

## 휴대폰만 있을 때 APK 만들기
이 프로젝트에는 `.github/workflows/build-apk.yml`이 들어 있습니다.

GitHub 저장소에 프로젝트 파일 전체를 올리면 GitHub Actions가 자동으로 APK를 빌드합니다.

1. GitHub에서 새 저장소 생성
2. 이 ZIP을 압축 해제한 뒤 프로젝트 파일 전체를 저장소 루트에 업로드
3. `Actions` 탭 → `Build Android APK`
4. 빌드가 끝나면 실행 결과의 `Artifacts`에서 `loosebox-calculator-apk` 다운로드
5. 압축을 풀어 `app-debug.apk`를 갤럭시에 설치

`main` 브랜치에 올리면 자동 빌드되며, Actions의 `Run workflow`로 수동 빌드도 가능합니다.

## 빌드 환경
- Android Gradle Plugin 9.2.0
- Gradle 9.4.1
- compileSdk 36
- minSdk 29
- Java 17
- ML Kit Korean Text Recognition 16.0.1

## 실제 테스트 때
앱에서 사진 분석 후 잘못 인식되면 `인식 원문 보기`를 눌러
OCR이 읽은 값과 열 분석 값을 확인할 수 있습니다.
그 화면 캡처를 기준으로 파싱 규칙을 추가 조정할 수 있습니다.


## v2 변경사항
- 갤럭시 기본 카메라로 촬영 후 앱에 사진이 첨부되지 않던 문제 수정
- 카메라 앱에 촬영 파일 URI 읽기/쓰기 권한을 명시적으로 부여
- 카메라가 RESULT_OK를 주지 않아도 실제 이미지가 저장되어 있으면 자동 첨부
- 촬영 취소/실패 시 빈 이미지 파일 자동 정리
- AndroidX 설정을 프로젝트 자체에서 활성화


## v3 변경사항
- 삼성 기본 카메라에서 "카메라가 계속 중단됨"이 발생할 수 있던 v2의 ClipData/수동 URI 권한 부여 로직 제거
- v1처럼 안정적인 EXTRA_OUTPUT + 표준 URI 권한 방식으로 카메라 실행
- 촬영 후 RESULT_OK 여부만 믿지 않고 실제 사진 파일 존재 여부를 확인해 자동 첨부
- MediaStore 반영이 늦는 경우를 위해 짧은 재확인 로직 추가
- OCR/표 파싱/낱다이 계산 로직은 변경하지 않음


## v4 핵심 변경
- 외부 삼성 기본 카메라 앱을 더 이상 호출하지 않습니다.
- 앱 안에 CameraX 촬영 화면을 직접 넣었습니다.
- 따라서 삼성 카메라가 RESULT_CANCELED를 반환하거나 "카메라가 계속 중단됨"이 발생하던 경로 자체를 제거했습니다.
- 앱 내부에서 촬영 → MediaStore 저장 → 촬영 URI를 메인 화면에 즉시 전달합니다.
- 사진첩 선택, ML Kit OCR, 표 파싱, 낱다이 계산 로직은 그대로 유지합니다.


## v5 수정
- v4 CameraActivity 컴파일 오류 수정
- `ImageCaptureException` import 누락을 추가
- 앱 내 CameraX 촬영 방식은 그대로 유지


## v6 핵심 수정
- v5에서 CameraActivity 클래스는 있었지만 AndroidManifest.xml에 등록이 빠져
  `출고장 촬영` 버튼을 눌러도 앱 내부 카메라 화면을 열 수 없던 문제를 수정했습니다.
- CameraActivity를 앱 Manifest에 정식 등록했습니다.
- CameraX 앱 내부 촬영 / 사진첩 / OCR / 낱다이 계산 로직은 그대로 유지합니다.


## v7 개선
- CameraX 촬영을 `CAPTURE_MODE_MAXIMIZE_QUALITY`로 변경
- 4:3 문서 촬영 비율 사용
- JPEG 품질 100
- 플래시 자동
- 1차 OCR에서 혼합 PLT를 못 찾으면 자동으로 흑백/대비 강화 후 2차 OCR 수행
- 사진첩 사진도 동일한 정밀 재인식 fallback 적용
- 기존 낱다이 계산 규칙은 변경하지 않음
