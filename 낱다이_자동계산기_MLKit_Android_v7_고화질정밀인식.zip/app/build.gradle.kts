plugins {
    id("com.android.application")
}

android {
    namespace = "com.safeasy.loosebox"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.safeasy.loosebox"
        minSdk = 29
        targetSdk = 36
        versionCode = 7
        versionName = "1.6"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // 한국어 OCR 모델을 앱에 포함합니다.
    // 첫 실행 시 모델 다운로드를 기다리지 않고 기기에서 바로 동작합니다.
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")

        // 앱 내부 카메라(CameraX): 외부 삼성 카메라 앱으로 넘기지 않습니다.
        implementation("androidx.activity:activity:1.10.1")
        implementation("androidx.core:core:1.15.0")
        implementation("androidx.camera:camera-core:1.4.2")
        implementation("androidx.camera:camera-camera2:1.4.2")
        implementation("androidx.camera:camera-lifecycle:1.4.2")
        implementation("androidx.camera:camera-view:1.4.2")
}
