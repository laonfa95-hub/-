package com.safeasy.loosebox;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

public class CameraActivity extends ComponentActivity {

    private static final int REQ_CAMERA_PERMISSION = 2001;

    private PreviewView previewView;
    private ImageCapture imageCapture;
    private Button captureButton;
    private TextView status;
    private ProcessCameraProvider cameraProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        setContentView(buildUi());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            requestPermissions(
                    new String[]{Manifest.permission.CAMERA},
                    REQ_CAMERA_PERMISSION
            );
        }
    }

    private FrameLayout buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(
                previewView,
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                )
        );

        status = new TextView(this);
        status.setText("출고장이 화면에 꽉 차도록 맞춰주세요.");
        status.setTextColor(Color.WHITE);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0x99000000);
        status.setPadding(dp(12), dp(8), dp(12), dp(8));

        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        statusLp.gravity = Gravity.TOP;
        statusLp.setMargins(dp(16), dp(18), dp(16), 0);
        root.addView(status, statusLp);

        captureButton = new Button(this);
        captureButton.setText("📷 촬영");
        captureButton.setTextSize(20);
        captureButton.setAllCaps(false);
        captureButton.setEnabled(false);
        captureButton.setOnClickListener(v -> takePhoto());

        FrameLayout.LayoutParams captureLp = new FrameLayout.LayoutParams(
                dp(180),
                dp(64)
        );
        captureLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        captureLp.setMargins(0, 0, 0, dp(34));
        root.addView(captureButton, captureLp);

        return root;
    }

    private void startCamera() {
        status.setText("카메라 준비 중…");

        ListenableFuture<ProcessCameraProvider> future =
                ProcessCameraProvider.getInstance(this);

        future.addListener(() -> {
            try {
                cameraProvider = future.get();

                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                imageCapture = new ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .setJpegQuality(95)
                        .build();

                CameraSelector selector = CameraSelector.DEFAULT_BACK_CAMERA;

                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(
                        this,
                        selector,
                        preview,
                        imageCapture
                );

                captureButton.setEnabled(true);
                status.setText("출고장이 화면에 꽉 차도록 맞춘 뒤 촬영하세요.");

            } catch (Exception e) {
                captureButton.setEnabled(false);
                status.setText("카메라 시작 실패");
                Toast.makeText(
                        this,
                        "카메라를 시작하지 못했습니다: " + e.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void takePhoto() {
        if (imageCapture == null) return;

        captureButton.setEnabled(false);
        status.setText("사진 저장 중…");

        ContentValues values = new ContentValues();
        values.put(
                MediaStore.Images.Media.DISPLAY_NAME,
                "loosebox_" + System.currentTimeMillis()
        );
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LooseBox");

        ImageCapture.OutputFileOptions options =
                new ImageCapture.OutputFileOptions.Builder(
                        getContentResolver(),
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        values
                ).build();

        imageCapture.takePicture(
                options,
                ContextCompat.getMainExecutor(this),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(ImageCapture.OutputFileResults output) {
                        Uri savedUri = output.getSavedUri();

                        if (savedUri == null) {
                            captureButton.setEnabled(true);
                            status.setText("저장된 사진을 찾지 못했습니다.");
                            return;
                        }

                        Intent result = new Intent();
                        result.setData(savedUri);
                        result.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        setResult(Activity.RESULT_OK, result);
                        finish();
                    }

                    @Override
                    public void onError(ImageCaptureException exception) {
                        captureButton.setEnabled(true);
                        status.setText("촬영 실패. 다시 시도해주세요.");
                        Toast.makeText(
                                CameraActivity.this,
                                "촬영 실패: " + exception.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        );
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_CAMERA_PERMISSION) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera();
            } else {
                Toast.makeText(
                        this,
                        "출고장 촬영을 사용하려면 카메라 권한이 필요합니다.",
                        Toast.LENGTH_LONG
                ).show();
                setResult(Activity.RESULT_CANCELED);
                finish();
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (cameraProvider != null) {
            cameraProvider.unbindAll();
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density
        );
    }
}
