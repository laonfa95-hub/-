plugins {
    id("com.android.application")
}

android {
    namespace = "com.safeasy.loosebox"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.safeasy.loosebox"
        minSdk = 29
        targetSdk = 36
        versionCode = 11
        versionName = "2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // 한국어 OCR 모델을 앱에 포함: 인식 자체는 기기에서 처리됩니다.
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")

    // ML Kit 문서 스캐너: 자동 문서 감지/크롭/기울기 보정/필터 UI
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0")

    // Activity Result API
    implementation("androidx.activity:activity:1.10.1")
    implementation("androidx.core:core:1.15.0")
}
